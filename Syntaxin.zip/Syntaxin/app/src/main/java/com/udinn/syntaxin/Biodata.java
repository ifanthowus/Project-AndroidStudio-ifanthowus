package com.udinn.syntaxin;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Biodata extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biodata);
    }
}