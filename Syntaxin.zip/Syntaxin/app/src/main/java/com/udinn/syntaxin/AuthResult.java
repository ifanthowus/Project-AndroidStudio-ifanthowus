package com.udinn.syntaxin;

public class AuthResult {
}
